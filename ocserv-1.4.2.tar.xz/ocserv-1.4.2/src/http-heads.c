/* ANSI-C code produced by gperf version 3.2.1 */
/* Command-line: gperf --global-table -t --output-file /home/nmav/projects/openconnect/ocserv/build/meson-dist/ocserv-1.4.2//src/http-heads.c /home/nmav/projects/openconnect/ocserv/build/meson-dist/ocserv-1.4.2//src/http-heads.gperf  */
/* Computed positions: -k'3,8' */

#if !((' ' == 32) && ('!' == 33) && ('"' == 34) && ('#' == 35) \
      && ('%' == 37) && ('&' == 38) && ('\'' == 39) && ('(' == 40) \
      && (')' == 41) && ('*' == 42) && ('+' == 43) && (',' == 44) \
      && ('-' == 45) && ('.' == 46) && ('/' == 47) && ('0' == 48) \
      && ('1' == 49) && ('2' == 50) && ('3' == 51) && ('4' == 52) \
      && ('5' == 53) && ('6' == 54) && ('7' == 55) && ('8' == 56) \
      && ('9' == 57) && (':' == 58) && (';' == 59) && ('<' == 60) \
      && ('=' == 61) && ('>' == 62) && ('?' == 63) && ('A' == 65) \
      && ('B' == 66) && ('C' == 67) && ('D' == 68) && ('E' == 69) \
      && ('F' == 70) && ('G' == 71) && ('H' == 72) && ('I' == 73) \
      && ('J' == 74) && ('K' == 75) && ('L' == 76) && ('M' == 77) \
      && ('N' == 78) && ('O' == 79) && ('P' == 80) && ('Q' == 81) \
      && ('R' == 82) && ('S' == 83) && ('T' == 84) && ('U' == 85) \
      && ('V' == 86) && ('W' == 87) && ('X' == 88) && ('Y' == 89) \
      && ('Z' == 90) && ('[' == 91) && ('\\' == 92) && (']' == 93) \
      && ('^' == 94) && ('_' == 95) && ('a' == 97) && ('b' == 98) \
      && ('c' == 99) && ('d' == 100) && ('e' == 101) && ('f' == 102) \
      && ('g' == 103) && ('h' == 104) && ('i' == 105) && ('j' == 106) \
      && ('k' == 107) && ('l' == 108) && ('m' == 109) && ('n' == 110) \
      && ('o' == 111) && ('p' == 112) && ('q' == 113) && ('r' == 114) \
      && ('s' == 115) && ('t' == 116) && ('u' == 117) && ('v' == 118) \
      && ('w' == 119) && ('x' == 120) && ('y' == 121) && ('z' == 122) \
      && ('{' == 123) && ('|' == 124) && ('}' == 125) && ('~' == 126))
/* The character set is not based on ISO-646.  */
#error "gperf generated tables don't work with this execution character set. Please report a bug to <bug-gperf@gnu.org>."
#endif

#line 1 "/home/nmav/projects/openconnect/ocserv/build/meson-dist/ocserv-1.4.2//src/http-heads.gperf"

#include "worker.h"
#line 6 "/home/nmav/projects/openconnect/ocserv/build/meson-dist/ocserv-1.4.2//src/http-heads.gperf"
struct http_headers_st { const char *name; unsigned id; };

#define TOTAL_KEYWORDS 17
#define MIN_WORD_LENGTH 6
#define MAX_WORD_LENGTH 34
#define MIN_HASH_VALUE 6
#define MAX_HASH_VALUE 40
/* maximum key range = 35, duplicates = 0 */

#ifdef __GNUC__
__inline
#else
#ifdef __cplusplus
inline
#endif
#endif
static unsigned int
hash (register const char *str, register size_t len)
{
  static const unsigned char asso_values[] =
    {
      41, 41, 41, 41, 41, 41, 41, 41, 41, 41,
      41, 41, 41, 41, 41, 41, 41, 41, 41, 41,
      41, 41, 41, 41, 41, 41, 41, 41, 41, 41,
      41, 41, 41, 41, 41, 41, 41, 41, 41, 41,
      41, 41, 41, 41, 41, 41, 41, 41, 41, 41,
      15, 41, 41, 41, 41, 41, 41, 41, 41, 41,
      41, 41, 41, 41, 41,  0, 20,  0,  5, 41,
      10, 41, 15, 41, 41, 41, 41,  0, 41, 41,
      41, 41, 41,  5, 41, 41, 41, 41, 41, 41,
      41, 41, 41, 41, 41, 41, 41, 41, 41, 41,
      41,  5, 41, 41, 41,  5, 41, 41, 41, 41,
       0,  0, 41, 41,  0, 41,  0, 41, 41, 41,
      41, 41,  0, 41, 41, 41, 41, 41, 41, 41,
      41, 41, 41, 41, 41, 41, 41, 41, 41, 41,
      41, 41, 41, 41, 41, 41, 41, 41, 41, 41,
      41, 41, 41, 41, 41, 41, 41, 41, 41, 41,
      41, 41, 41, 41, 41, 41, 41, 41, 41, 41,
      41, 41, 41, 41, 41, 41, 41, 41, 41, 41,
      41, 41, 41, 41, 41, 41, 41, 41, 41, 41,
      41, 41, 41, 41, 41, 41, 41, 41, 41, 41,
      41, 41, 41, 41, 41, 41, 41, 41, 41, 41,
      41, 41, 41, 41, 41, 41, 41, 41, 41, 41,
      41, 41, 41, 41, 41, 41, 41, 41, 41, 41,
      41, 41, 41, 41, 41, 41, 41, 41, 41, 41,
      41, 41, 41, 41, 41, 41, 41, 41, 41, 41,
      41, 41, 41, 41, 41, 41
    };
  register unsigned int hval = len;

  switch (hval)
    {
      default:
        hval += asso_values[(unsigned char)str[7]];
#if (defined __cplusplus && (__cplusplus >= 201703L || (__cplusplus >= 201103L && defined __clang__ && __clang_major__ + (__clang_minor__ >= 9) > 3))) || (defined __STDC_VERSION__ && __STDC_VERSION__ >= 202000L && ((defined __GNUC__ && __GNUC__ >= 10) || (defined __clang__ && __clang_major__ >= 9)))
      [[fallthrough]];
#elif (defined __GNUC__ && __GNUC__ >= 7) || (defined __clang__ && __clang_major__ >= 10)
      __attribute__ ((__fallthrough__));
#endif
      /*FALLTHROUGH*/
      case 7:
      case 6:
      case 5:
      case 4:
      case 3:
        hval += asso_values[(unsigned char)str[2]];
        break;
    }
  return hval;
}

#if (defined __GNUC__ && __GNUC__ + (__GNUC_MINOR__ >= 6) > 4) || (defined __clang__ && __clang_major__ >= 3)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wmissing-field-initializers"
#endif
static const struct http_headers_st wordlist[] =
  {
    {""}, {""}, {""}, {""}, {""}, {""},
#line 8 "/home/nmav/projects/openconnect/ocserv/build/meson-dist/ocserv-1.4.2//src/http-heads.gperf"
    {"Cookie", HEADER_COOKIE},
    {""}, {""}, {""},
#line 17 "/home/nmav/projects/openconnect/ocserv/build/meson-dist/ocserv-1.4.2//src/http-heads.gperf"
    {"X-CSTP-MTU", HEADER_CSTP_MTU},
    {""}, {""},
#line 24 "/home/nmav/projects/openconnect/ocserv/build/meson-dist/ocserv-1.4.2//src/http-heads.gperf"
    {"Authorization", HEADER_AUTHORIZATION},
    {""},
#line 12 "/home/nmav/projects/openconnect/ocserv/build/meson-dist/ocserv-1.4.2//src/http-heads.gperf"
    {"Connection", HEADER_CONNECTION},
    {""}, {""}, {""},
#line 18 "/home/nmav/projects/openconnect/ocserv/build/meson-dist/ocserv-1.4.2//src/http-heads.gperf"
    {"X-CSTP-Address-Type", HEADER_CSTP_ATYPE},
#line 9 "/home/nmav/projects/openconnect/ocserv/build/meson-dist/ocserv-1.4.2//src/http-heads.gperf"
    {"User-Agent", HEADER_USER_AGENT},
    {""},
#line 10 "/home/nmav/projects/openconnect/ocserv/build/meson-dist/ocserv-1.4.2//src/http-heads.gperf"
    {"X-CSTP-Accept-Encoding", HEADER_CSTP_ENCODING},
#line 14 "/home/nmav/projects/openconnect/ocserv/build/meson-dist/ocserv-1.4.2//src/http-heads.gperf"
    {"X-DTLS-CipherSuite", HEADER_DTLS_CIPHERSUITE},
#line 23 "/home/nmav/projects/openconnect/ocserv/build/meson-dist/ocserv-1.4.2//src/http-heads.gperf"
    {"X-Support-HTTP-Auth", HEADER_SUPPORT_SPNEGO},
#line 13 "/home/nmav/projects/openconnect/ocserv/build/meson-dist/ocserv-1.4.2//src/http-heads.gperf"
    {"X-DTLS-Master-Secret", HEADER_MASTER_SECRET},
    {""},
#line 11 "/home/nmav/projects/openconnect/ocserv/build/meson-dist/ocserv-1.4.2//src/http-heads.gperf"
    {"X-DTLS-Accept-Encoding", HEADER_DTLS_ENCODING},
    {""}, {""},
#line 19 "/home/nmav/projects/openconnect/ocserv/build/meson-dist/ocserv-1.4.2//src/http-heads.gperf"
    {"X-CSTP-Hostname", HEADER_HOSTNAME},
    {""},
#line 22 "/home/nmav/projects/openconnect/ocserv/build/meson-dist/ocserv-1.4.2//src/http-heads.gperf"
    {"X-AnyConnect-Identifier-Platform", HEADER_PLATFORM},
    {""},
#line 21 "/home/nmav/projects/openconnect/ocserv/build/meson-dist/ocserv-1.4.2//src/http-heads.gperf"
    {"X-AnyConnect-Identifier-DeviceType", HEADER_DEVICE_TYPE},
#line 16 "/home/nmav/projects/openconnect/ocserv/build/meson-dist/ocserv-1.4.2//src/http-heads.gperf"
    {"X-CSTP-Base-MTU", HEADER_CSTP_BASE_MTU},
    {""},
#line 20 "/home/nmav/projects/openconnect/ocserv/build/meson-dist/ocserv-1.4.2//src/http-heads.gperf"
    {"X-CSTP-Full-IPv6-Capability", HEADER_FULL_IPV6},
    {""}, {""},
#line 15 "/home/nmav/projects/openconnect/ocserv/build/meson-dist/ocserv-1.4.2//src/http-heads.gperf"
    {"X-DTLS12-CipherSuite", HEADER_DTLS12_CIPHERSUITE}
  };
#if (defined __GNUC__ && __GNUC__ + (__GNUC_MINOR__ >= 6) > 4) || (defined __clang__ && __clang_major__ >= 3)
#pragma GCC diagnostic pop
#endif

const struct http_headers_st *
in_word_set (register const char *str, register size_t len)
{
  if (len <= MAX_WORD_LENGTH && len >= MIN_WORD_LENGTH)
    {
      register unsigned int key = hash (str, len);

      if (key <= MAX_HASH_VALUE)
        {
          register const char *s = wordlist[key].name;

          if (*str == *s && !strcmp (str + 1, s + 1))
            return &wordlist[key];
        }
    }
  return (struct http_headers_st *) 0;
}
